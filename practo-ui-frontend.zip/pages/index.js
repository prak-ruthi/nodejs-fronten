export default function Home() {
  return (
    <div>
      <h1>Welcome to Practo UI</h1>
      <p>This is a sample Next.js project.</p>
    </div>
  );
}
