# Practo UI
This is a basic Next.js project for Practo UI clone.